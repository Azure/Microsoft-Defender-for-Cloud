import logging
import os
import json
import requests  # Import the requests library


import azure.functions as func
# from jira import JIRA  # No longer using jira-python library
# from jira.exceptions import JIRAError # No longer using jira-python library


def map_mdc_severity_to_jira_priority(mdc_severity):
    """
    Maps Microsoft Defender for Cloud severity levels to Jira Priority names.
    (Still applicable for Recommendations as they also have severity levels)
    """
    severity_mapping = {
        "High": "Highest",
        "Medium": "High",
        "Low": "Medium",
        "Informational": "Low"  # Or "Lowest" or whatever is appropriate in your Jira
    }
    return severity_mapping.get(mdc_severity, "Medium") # Default to "Medium" if severity is not recognized


def main(req: func.HttpRequest) -> func.HttpResponse:
    """
    Azure Function to create a Jira Service Request ticket from Microsoft Defender for Cloud RECOMMENDATION data.
    Now using Jira Service Management REST API directly via 'requests' library.
    Returns structured JSON response including issueKey, issueUrl, and HTTP status code.
    """
    logging.info('Python HTTP trigger function processing request to create Jira Service Request using Jira REST API.')

    try:
        mdc_recommendation_data = req.get_json() # Expecting MDC RECOMMENDATION payload in JSON format
    except ValueError:
        logging.error("Request body is not valid JSON. Expecting an MDC RECOMMENDATION payload in JSON format.")
        return func.HttpResponse(
             json.dumps({
                 "status": "failure", # Indicate failure status
                 "errorCode": "InvalidRequestData",
                 "message": "Please pass a valid JSON request body containing an MDC RECOMMENDATION payload.",
             }),
             status_code=400,
             mimetype="application/json"
        )

    # Extract relevant data from MDC RECOMMENDATION payload (same as before)
    display_name = mdc_recommendation_data.get('displayName')
    status_code = mdc_recommendation_data.get('status', {}).get('code') # Get status.code safely
    description = mdc_recommendation_data.get('description')
    remediation_description = mdc_recommendation_data.get('remediationDescription')
    severity = mdc_recommendation_data.get('severity')
    link = mdc_recommendation_data.get('link')
    resource_name = mdc_recommendation_data.get('resourceName')
    resource_type = mdc_recommendation_data.get('resourceType')
    resource_uri = mdc_recommendation_data.get('resourceUri')
    source = mdc_recommendation_data.get('source')


    if not display_name or not status_code or not description or not resource_name or not resource_type:
        logging.warning("Missing essential fields in the MDC RECOMMENDATION payload (displayName, status.code, description, resourceName, resourceType).")
        return func.HttpResponse(
             json.dumps({
                 "status": "failure", # Indicate failure status
                 "errorCode": "IncompletePayload",
                 "message": "Incomplete MDC RECOMMENDATION payload. Missing essential fields (displayName, status.code, description, resourceName, resourceType).",
             }),
             status_code=400,
             mimetype="application/json"
        )

    jira_instance_url = os.environ.get('JIRA_BASE_URL') # Get Jira URL from settings
    jira_user_email = os.environ.get('JIRA_USER_EMAIL')
    jira_api_token = os.environ.get('JIRA_API_TOKEN')
    jira_service_desk_id = os.environ.get('JIRA_SERVICE_DESK_ID') # NEW: Get Service Desk ID from settings
    jira_request_type_id_mdc_recommendation = os.environ.get('JIRA_REQUEST_TYPE_ID_MDC_RECOMMENDATION') # Get Request Type ID from settings
    jira_project_key_service_request = os.environ.get('JIRA_PROJECT_KEY_SERVICE_REQUEST')
    jira_issue_type_name_service_request = os.environ.get('JIRA_ISSUE_TYPE_NAME_SERVICE_REQUEST')

    if not jira_instance_url or not jira_user_email or not jira_api_token or not jira_service_desk_id or not jira_request_type_id_mdc_recommendation: # Updated check to include new settings
        error_message = "Missing Jira connection settings in environment variables. Check JIRA_BASE_URL, JIRA_USER_EMAIL, JIRA_API_TOKEN, JIRA_SERVICE_DESK_ID, JIRA_REQUEST_TYPE_ID_MDC_RECOMMENDATION." # Updated error message
        logging.error(error_message)
        return func.HttpResponse(
             json.dumps({
                 "status": "failure", # Indicate failure status
                 "errorCode": "MissingSettings",
                 "message": error_message,
             }),
             status_code=500,
             mimetype="application/json"
        )

    api_endpoint = f"{jira_instance_url}/rest/servicedeskapi/request" # Jira Service Management REST API endpoint
    headers = {
        "Accept": "application/json",
        "Content-Type": "application/json"
    }
    auth = (jira_user_email, jira_api_token)

    # Construct Jira issue summary and description from MDC RECOMMENDATION data (same as before)
    jira_summary = f"MDC Recommendation: {display_name} for {resource_name}" # Concise summary
    jira_description = f"**Recommendation Display Name:** {display_name}\n\n**Status Code:** {status_code}\n\n**Description:** {description}\n\n**Remediation:** {remediation_description}\n\n**Severity:** {severity}\n\n**Recommendation Link:** {link}\n\n**Affected Resource:** {resource_name} ({resource_type})\n\n**Resource URI:** {resource_uri}\n\n**Source:** {source}" # Detailed description


    # Construct payload for Jira Service Management REST API (using requestFieldValues)
    payload = json.dumps({
        "serviceDeskId": jira_service_desk_id,
        "requestTypeId": jira_request_type_id_mdc_recommendation,
        "requestFieldValues": {
            "summary": jira_summary,
            "description": jira_description,
            # We are NOT setting priority via Request Type fields for now, let's keep using Jira priority field.
            # If you want to map MDC severity to a custom "Priority" field within the Request Type, you would add it here,
            # and potentially remove the "priority" field from the 'fields' section below.
        }
    })


    jira_priority_name = map_mdc_severity_to_jira_priority(severity) # Map MDC severity to Jira priority (still needed for Jira priority field)


    issue_dict = { # We still use issue_dict for standard Jira fields (project, issuetype, priority), but NOT for Request Type anymore
        'fields': {
            'project': {'key': jira_project_key_service_request},
            'issuetype': {'name': jira_issue_type_name_service_request},
            'summary': jira_summary, # Summary is also in requestFieldValues, but including it here for general Jira issue context (may be redundant, test if needed)
            'description': jira_description, # Description also in requestFieldValues, including for general Jira issue context (may be redundant, test if needed)
            'priority': {'name': jira_priority_name} # Set Jira priority based on mapping - kept as before, for Jira standard priority field.
        }
    }


    print(f"Request Payload for Jira API: {payload}") # Print payload for debugging
    print(f"issue_dict (standard fields): {issue_dict}") # Print issue_dict for debugging


    try:
        response = requests.post(api_endpoint, headers=headers, data=payload, auth=auth) # Use requests.post to call Jira REST API
        response.raise_for_status() # Raise HTTPError for bad responses (4xx or 5xx)


        # --- Process the successful response ---
        request_details = response.json()
        logging.info(f"Jira Service Request ticket created successfully! Request Key: {request_details['issueKey']}")
        issue_url = f"{jira_instance_url}/browse/{request_details['issueKey']}" # Construct issue URL using issueKey from response
        return func.HttpResponse(
            json.dumps({
                "status": "success", # Indicate success status
                "issueKey": request_details['issueKey'], # Return issue key
                "issueUrl": issue_url, # Return issue URL
                "httpStatusCode": response.status_code # Return HTTP status code (201 for success)
            }),
            status_code=201, # 201 Created status code for successful creation
            mimetype="application/json"
        )


    except requests.exceptions.HTTPError as http_err: # Catch HTTP errors from requests library
        error_message = f"HTTP error occurred: {http_err}, Response: {http_err.response.text}"
        logging.error(error_message)
        return func.HttpResponse(
            json.dumps({
                "status": "failure", # Indicate failure status
                "errorCode": "JiraAPIError",
                "message": "Failed to create Jira Service Request ticket due to Jira API error.",
                "jiraStatusCode": http_err.response.status_code if http_err.response else None, # Get status code if response is available
                "jiraErrorText": http_err.response.text if http_err.response else str(http_err), # Get response text or general error string
                "errorDetails": error_message,
                "httpStatusCode": http_err.response.status_code if http_err.response else 500 # Return HTTP status code from Jira API error, or 500 if unavailable
            }),
            status_code=http_err.response.status_code if http_err.response and 400 <= http_err.response.status_code < 600 else 500, # Use response status if available and in 4xx/5xx range, else default 500
            mimetype="application/json"
        )
    except Exception as e: # Catch any other exceptions
        error_message = f"Unexpected error: {e}"
        logging.exception(error_message) # Use logging.exception to capture full traceback
        return func.HttpResponse(
            json.dumps({
                "status": "failure", # Indicate failure status
                "errorCode": "FunctionError",
                "message": "Function execution failed due to an unexpected error.",
                "errorDetails": error_message,
                "httpStatusCode": 500 # Indicate function error with 500 status
            }),
            status_code=500,
            mimetype="application/json"
        )


if __name__ == "__main__":
    # Example of how to run the function locally for testing (outside Azure Functions host)
    import requests

    # Set environment variables for local testing (as in local.settings.json) - COMMENT OUT THESE LINES FOR func host start TESTING
    # os.environ['JIRA_BASE_URL'] = "YOUR_JIRA_BASE_URL" # Replace with your Jira Base URL for testing
    # os.environ['JIRA_USER_EMAIL'] = "YOUR_JIRA_USER_EMAIL" # Replace with your Jira user email for testing
    # os.environ['JIRA_API_TOKEN'] = "YOUR_JIRA_API_TOKEN" # Replace with your Jira API token for testing
    # os.environ['JIRA_PROJECT_KEY_SERVICE_REQUEST'] = "YOUR_JIRA_PROJECT_KEY" # Replace with your Service Request project key
    # os.environ['JIRA_ISSUE_TYPE_NAME_SERVICE_REQUEST'] = "Service Request" # Or your Issue Type Name
    # os.environ['JIRA_SERVICE_DESK_ID'] = "YOUR_SERVICE_DESK_ID" # NEW: Replace with your Service Desk ID for testing
    # os.environ['JIRA_REQUEST_TYPE_ID_MDC_RECOMMENDATION'] = "YOUR_REQUEST_TYPE_ID" # NEW: Replace with your Request Type ID for testing


    test_payload = {
      "displayName": "Ensure that multi-factor authentication should be enabled for all privileged roles - TEST REC - REST API",
      "status": {
        "code": "NotApplicable"
      },
      "description": "This is a test MDC Recommendation to simulate MFA recommendation, using Jira REST API.",
      "remediationDescription": "Enable MFA for all accounts that are assigned privileged Azure Active Directory roles.",
      "severity": "High",
      "link": "https://portal.azure.com/#test-recommendation-link-rest-api",
      "resourceName": "test-subscription-rest-api",
      "resourceType": "Subscription",
      "resourceUri": "/subscriptions/test-subscription-id-rest-api",
      "source": "Microsoft Defender for Cloud (REST API Test)"
    }


    headers = {'Content-Type': 'application/json'}

    class MockHttpRequest:
        def get_json(self):
            return test_payload
    mock_request = MockHttpRequest()


    response = main(mock_request) # Call the main function

    print(f"Status Code: {response.status_code}")
    print("Response Body:")
    print(response.get_body().decode()) # Decode bytes to string for printing