#!/bin/sh
echo "installing curl" >> /var/log/mdeinstall
sudo apt-get -y install -f curl >> /var/log/mdeinstall
echo ""  >> /var/log/mdeinstall
echo ""  >> /var/log/mdeinstall
echo "installing libplist-utils" >> /var/log/mdeinstall
sudo apt-get -y install -f libplist-utils  >> /var/log/mdeinstall
echo ""  >> /var/log/mdeinstall
echo ""  >> /var/log/mdeinstall
echo "getting closet entry" >> /var/log/mdeinstall
curl -o microsoft.list https://packages.microsoft.com/config/ubuntu/18.04/prod.list >> /var/log/mdeinstall
echo ""  >> /var/log/mdeinstall
echo ""  >> /var/log/mdeinstall
echo "installing repo configuration" >> /var/log/mdeinstall
sudo mv ./microsoft.list /etc/apt/sources.list.d/microsoft-prod.list >> /var/log/mdeinstall
echo ""  >> /var/log/mdeinstall
echo ""  >> /var/log/mdeinstall
echo "installing gpg" >> /var/log/mdeinstall
sudo apt-get -y install -f gpg >> /var/log/mdeinstall
echo ""  >> /var/log/mdeinstall
echo ""  >> /var/log/mdeinstall
echo "installing Microsoft GPG public key" >> /var/log/mdeinstall
curl https://packages.microsoft.com/keys/microsoft.asc | sudo apt-key add - >> /var/log/mdeinstall
echo ""  >> /var/log/mdeinstall
echo ""  >> /var/log/mdeinstall
echo "installing https driver" >> /var/log/mdeinstall
sudo apt-get -y install -f apt-transport-https  >> /var/log/mdeinstall
echo ""  >> /var/log/mdeinstall
echo ""  >> /var/log/mdeinstall
echo "installing python" >> /var/log/mdeinstall
sudo apt-get -y install -f python >> /var/log/mdeinstall
echo ""  >> /var/log/mdeinstall
echo ""  >> /var/log/mdeinstall
echo "updating repository metadata" >> /var/log/mdeinstall
sudo apt-get -y update >> /var/log/mdeinstall
echo ""  >> /var/log/mdeinstall
echo ""  >> /var/log/mdeinstall
echo "installing Microsoft Defender for Endpoints" >> /var/log/mdeinstall
sudo apt-get -y install -f mdatp >> /var/log/mdeinstall
cat /etc/apt/sources.list.d/* >> /var/log/mdeinstall
deb [arch=arm64,armhf,amd64] https://packages.microsoft.com/ubuntu/18.04/prod insiders-fast main >> /var/log/mdeinstall
deb [arch=amd64] https://packages.microsoft.com/ubuntu/18.04/prod bionic main >> /var/log/mdeinstall
sudo apt -t bionic install mdatp >> /var/log/mdeinstall
echo ""  >> /var/log/mdeinstall
echo ""  >> /var/log/mdeinstall
echo "finished application installation" >> /var/log/mdeinstall
echo "running mdatp onboarding script" >> /var/log/mdeinstall
chmod +x MicrosoftDefenderATPOnboardingLinuxServer.py
python MicrosoftDefenderATPOnboardingLinuxServer.py >> /var/log/mdeinstall
echo "finished onboarding script" >> /var/log/mdeinstall